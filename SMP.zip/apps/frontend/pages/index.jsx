export default function Home() {
  return (
    <main style={{ fontFamily: 'Inter, sans-serif', padding: '3rem' }}>
      <h1>Sunmart Portal</h1>
      <p>Hero | Pricing | Checkout placeholder portal.</p>
    </main>
  );
}

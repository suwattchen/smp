const nextConfig = {
  output: 'standalone',
};

export default nextConfig;
